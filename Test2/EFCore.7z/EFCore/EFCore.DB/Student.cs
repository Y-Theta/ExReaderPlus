﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EFCore.DB
{
    public class Student
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}

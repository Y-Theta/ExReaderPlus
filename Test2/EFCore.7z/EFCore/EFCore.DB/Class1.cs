﻿using System;

namespace EFCore.DB
{
    public class Class1
    {
    }
}
